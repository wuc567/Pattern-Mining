# include <afxwin.h>
# include <iostream>
# include <string>
# include <vector>
# include <fstream>
# include <map>
using namespace std;
#define K 80000    //The sequence number of sequence database
#define M 100   //The length of pattern
#define N 200  //The length of sequence

struct seqdb                 
{
	int len;				// the length of the sequence
	int S[N];              // sequence
	int id;                  // sequence id
//	char S[N];              // sequence
} sDB[K];                 // sequence database
seqdb curS;  //current sequence

class IInt
{
public:
	int *store;
	int length;
	IInt();
	IInt(const IInt &another);
	~IInt();
	int compare(IInt &another);
	int operator [](int position)
	{
		return store[position];
	}
	IInt & operator +=(int value)
	{
		store[length]=value;
		length++;
		return *this;
	}
	IInt  substr(int start,int end);
	bool operator !=(IInt & another);
	bool operator==(IInt & another);
	IInt & operator =(int value);
	void display();
	IInt & operator =(const IInt & another);
    friend bool operator < (const class IInt &ls, const class IInt &rs);
};
inline bool operator < (const class IInt &ls, const class IInt &rs)
{
	for (int i=0;i<(ls.length <rs.length ?ls.length :rs.length );i++)
		if (ls.store [i]<rs.store [i])
			return true;
		return (ls.length<rs.length)? true:false;
		
}
IInt::IInt(const IInt  & another) 
{
	store=new int [1000];
	length=another.length ;
	for (int i=0;i<length;i++)
	{
		store[i]=another.store [i];
	}
}
IInt::IInt()
{
	store=new int [1000];
	length=0;
}
IInt::~IInt ()
{
	delete []store;
}
IInt & IInt::operator = (int value)
{
	length=1;
	store[0]=value;
	return * this;
}
void IInt::display ()
{
	for (int i=0;i<length-1;i++)
		cout <<store[i]<<",";
	cout <<store[length-1]<<" ";
}
IInt & IInt::operator = (const IInt & another)
{
	length=another.length ;
	for (int i=0;i<length;i++)
	{
		store[i]=another.store [i];
	}
	return *this;
}
bool IInt::operator == (IInt & another)
{
	if (length!=another.length )
		return false;
	for (int i=0;i<length;i++)
	{
		if (store[i]!=another.store [i])
			return false;
	}
	return true;
}
bool IInt::operator != (IInt & another)
{
	return ! this->operator == (another);
}

IInt  IInt::substr(int start,int len)
{
	IInt a;
	a.length =len;
	for (int i=0;i<len;i++)
	{
		a.store [i]=this->store[i+start];
	}
	return a;
}
int IInt::compare (IInt &another )
{
		for (int i=0;i<length;i++)
		{
			if (store[i]!=another.store [i])
				break;
		}
		if (i==length && i==another.length )
			return 0;
		else if (i==length)
			return -1;
		else if (store[i]>another.store [i])
			return 1;
		else
			return -1;
}

  

int nn;
vector <int> eSet ;             //store all frequent items

int minsup;             
int minlen,maxlen;   //length constraint
int mingap,maxgap; //gap constraint
int NumbS;
struct Pos
{
	vector <int> pos;    //position
};
struct ISupSet            // support set od pattern
{
	int id;               // id
	vector <Pos> poset;     // position set
};

//vector <ISupSet> I, Iseq, IPLus, IPLUS;   
//vector <ISupSet>  Iseq, IPLus, IPLUS;   

struct Freq_ptn            // frequent pattern
{
	int length;
	vector <int> ptn;
};
vector <Freq_ptn> Fre;    // frequent pattern set

struct All_Fre    //frequent pattern with length
{
	int length;           
	vector <Freq_ptn> Fre;    
};
vector <All_Fre> AllFre;    // all frequent pattern set
struct sub_ptn_struct   //a[0,3]c => start[min,max]end
{
	int start,end;		
	int min,max;
};
vector <sub_ptn_struct> sub_ptn;
int ptn_len; 
//char S[N];
int compnum = 0;

void min_freItem()
{
	map <IInt, int > counter; 
	IInt mine;
	for(int t = 0; t < NumbS; t++)
	{
		//strcpy(S,sDB[t].S);
		 curS=sDB[t];
		for(int i=0;i<curS.len;i++)
		{
			mine=curS.S[i];
			int val=mine[0];
			counter[mine]++;	
		}
	}
	nn = 0;
	for (map <IInt,int >::iterator the_iterator = counter.begin (); the_iterator!= counter.end (); ++the_iterator)
	{
		//eSet[nn++] = the_iterator->first.at(0);
			IInt cand;
			cand=the_iterator->first;
			int valu=cand.store [0];
			eSet.push_back(valu);  //add to eSet
			//int check0=eSet[nn];
			nn++;
	}
	//int abc;
	//abc=5;
}

// print P
void disp_P(vector <int> p)    
{
	int plen, m;
	cout << " = " ;
	plen = p.size(); 
	for(m = 0; m < plen; m++)
		cout << p[m]<<",";
	cout << endl;
}

//print sub_ptn[ptn_len]
void disp_pattern(vector <sub_ptn_struct> sub_ptn) 
{
	ptn_len = sub_ptn.size();
	for(int i = 0; i < ptn_len; i++)
	    cout << sub_ptn[i].start << '\t' << sub_ptn[i].min << '\t' << sub_ptn[i].max << '\t' <<sub_ptn[i].end << endl;
}

//compute support set I(P[0]) in sDB
int  SizeOneSup(seqdb sDB[M], vector <int> &P, vector <ISupSet> & I)
{
	int i, l, len, plen; 
	int support = 0;

	plen = P.size();
	if(plen == 1)
	{
		int lines=0;	//changed
		for(i = 0; i < NumbS; i++)
		{
			//if (sDB[i].len<=3)
			//	continue;
			bool first =true ;
			for(l = 0; l < sDB[i].len; l++)   
			{
				//I.resize(i + 1);//��Ч�Ĳ�����룻
				if(sDB[i].S[l] == P[plen - 1])
				{
					if (first ==true)
					{
						lines++;
						I.resize (lines);
						first =false;
					}			
					len = I[lines-1].poset.size();
					I[lines-1].poset.resize(len + 1);
					I[lines-1].poset[len].pos.resize(1);
					I[lines-1].id = sDB[i].id;				
					I[lines-1].poset[len].pos[0] = l;
					support++;
				}
			}
		}
	}
	return support;
}

//print Fre
void disp_Fre(vector <Freq_ptn> Fre)   
{
	int fsum, flen, i = 0, j;
	cout << "Fre = {  ";
	fsum = Fre.size();
	if(fsum >1)
	{
		for(i = 0; i < fsum - 1; i++)
		{	
			flen = Fre[i].ptn.size();
			for(j = 0; j < flen; j++)
			{
				cout << Fre[i].ptn[j];
			}
			cout << "  ,  ";
		}
	}
	if(i == fsum - 1)
	{
		flen = Fre[i].ptn.size();
		for(j = 0; j < flen; j++)
		{
			cout << Fre[i].ptn[j];
		}
		cout << "  }";
	}
	cout << endl << endl;
}

//Find the maximum of two numbers
int imax(int x, int y)    
{
	int z;
	if(x > y)	z = x;
	else		z = y;
	return (z);
}

//compute mininum loaction that satisfy gap constraint
int next(seqdb &seq, int p, int max, int a, int b)
{
	int i = imax(max+1, a);
	bool flag = false;
	for(; i <= b; i++)
	{
		if(seq.S[i] == p)
		{
			flag = true;
			break;
		}			
	}
	if(flag == true)
		return i;
	else
		return -1;
}

int INSgrow_Gap(seqdb sDB[M], vector <sub_ptn_struct> &sub_ptn, vector <ISupSet> &I, vector <ISupSet> &IPLUS)
{
	//IPLUS.resize(0);
	int support=0;
	int i;
	ptn_len = sub_ptn.size();
	int p = sub_ptn[ptn_len - 1].end;
	//��I��ֵ��IPLUS
	int isize =I.size();
	IPLUS.resize(I.size());
	IPLUS = I;
	for(i = 0; i < isize; i++)
	{
		//if(strlen(sDB[i].S) > 0)
		int lines=I[i].id;
		if(sDB[lines].len > 0)
		{	
			//	Ѱ��sDB[i].S�ϵ����г���
			int ptn_len;
			ptn_len = sub_ptn.size();
			for(int j = 0;j<IPLUS[i].poset.size();j++)
			{
				Pos apos = IPLUS[i].poset[j];
				int len = apos.pos.size();
				if(len == sub_ptn.size())
				{
					int max = apos.pos[len - 1]; // max: last value of position of previous one
					int a = 0, b = 0, l = -1;
					a = max + sub_ptn[ptn_len - 1].min +1;
					b = max + sub_ptn[ptn_len - 1].max +1;
					b=(b>(sDB[lines].len-1))?(sDB[lines].len-1):b;
					//if(a > strlen(sDB[i].S))
					if(a > sDB[lines].len)
						continue;
					if(max <= b)
					{
						l = next(sDB[lines], p, max, a, b);   // l: mininum loaction that satisfy gap constraint
					}
					if(l != -1 && l <= b)
					{
						if( (l - IPLUS[i].poset[j].pos[0] + 1) < minlen || (l - IPLUS[i].poset[j].pos[0] + 1) > maxlen )  //whether satisfy length constraint
						{
							continue;
						} 
						for( int m = j; m >= 0 ; m--)
						{
							if(IPLUS[i].poset[m].pos[len] == l) // overlap, exit
							{
								m++;
								break;   
							}
							if(m == 0)  //match, exit
							{
								int Iqlen = IPLUS[i].poset[j].pos.size();    // the number of positions
								IPLUS[i].poset[j].pos.resize(Iqlen + 1);
								IPLUS[i].poset[j].pos[Iqlen] = l;          
								support++;
								break;
							}
						}
					}
				}
			}
		}
	}
	return support;
}


void mineFre(int support, seqdb sDB[M], vector <int> &P, vector <ISupSet> &I)
{
	vector <int> Q;
	if(support >= minsup)     // P is frequent
	{
		int fsum, plen;
		fsum = Fre.size();
		Fre.resize(fsum + 1);
		plen = P.size();
		Fre[fsum].length = plen;
		Fre[fsum].ptn.resize(plen);
		Fre[fsum].ptn = P;         // add P into frequent set
		int t;
		Q.resize(plen);
		Q=P;
		/*for(t = 0; t < plen; t++)
		{
			int val= P[t];
			Q[t] = P[t];
		}*/
		for(int e = 0; e < nn; e++) 
		{
			int qlen = P.size()+1;
			Q.resize(qlen);
			Q[qlen-1] = eSet[e];
			sub_ptn.resize(qlen-1);
			int k = 0;
			int val;
			for(; k < qlen-1; k++)
			{
				sub_ptn[k].start = Q[k];
				sub_ptn[k].min = mingap;
				sub_ptn[k].max = maxgap;
				sub_ptn[k].end = Q[k + 1];
				val=sub_ptn[k].end;
			}
			compnum++;
			vector <ISupSet> IPLUS;
			int support=INSgrow_Gap(sDB, sub_ptn, I, IPLUS);   // compute IPLUS
			mineFre(support,sDB, Q, IPLUS);
		}
		
	}
}


void transform(vector <Freq_ptn> &Fre)
{
	//AllFre.resize(0);
	int length=0, AFlen, Fsum, Flen, i, j;
	Fsum = Fre.size();
	if(Fsum > 1)            
	{
		length = Fre[0].length;
		for(i = 1; i < Fsum; i++)
		{
			if(Fre[i].length > length)
				length = Fre[i].length;
		}
	}
	AllFre.resize(length);        
	for(i = 0; i < length; i++)          
	{
		AllFre[i].length = i + 1;
		AllFre[i].Fre.resize(0);
	}
	
	for(i = 0; i < length; i++)
	{
		for(j = 0; j < Fsum; j++)
		{
			if(Fre[j].length == AllFre[i].length)
			{
				AFlen = AllFre[i].Fre.size();
				AllFre[i].Fre.resize(AFlen + 1);
				Flen = Fre[j].ptn.size();
				AllFre[i].Fre[AFlen].ptn.resize(Flen);
				AllFre[i].Fre[AFlen].ptn = Fre[j].ptn;
			}
		}
	}
}


void disp_AllFre(vector <All_Fre> &AllFre)      // print all frequent pattern
{
	cout << "All Frequent Patterns are as follows: " << endl;
	int total = 0;
	int t, AFsum, length;
	AFsum = AllFre.size();
	for(t = 0; t < AFsum; t++)
	{
		length = AllFre[t].length;
		cout << "The length is " << length << endl;

		int fsum, flen, i, j;
		fsum = AllFre[t].Fre.size();
		flen = AllFre[t].Fre[0].ptn.size();
		if(flen == 1)
		{
			for(i = 0; i < fsum; i++)
			{	
		
				cout << AllFre[t].Fre[i].ptn[0] << "\t";
			}
			total += fsum;

		}
		else if(flen > 1)
		{
			for(i = 0; i < fsum; i++)
			{
				for(j = 0; j < flen; j++)
				{
					cout << AllFre[t].Fre[i].ptn[j]<<",";
				}
				cout << "\t";
			}
			total += fsum;

		}
		cout << endl;
		cout << "The Number of Length " << length << " is " << fsum << endl; 
	}
	cout << "The Total of AllFre is " << total << endl; 
}

void read_file()
{
	fstream file;
	char filename[256];//="bms2.txt";//"kddcup.txt";
	cout <<"---------------------------------------------------------------------------\nPlease input file name:";
	cin>>filename;
	cout <<filename<<endl;

	fstream infile(filename,ios::in); //filenameΪָ�����ļ�����
	if(!infile)
	{
        cout<<"open error!"<<endl;
        exit(1);
	}
	int b=1;
	int i;
	int max=0;
	int lines=0;
	while (!infile.eof())
	{
		b=1;
		for (i=0;b!=-2;)
		{
			infile>>b;    //���ļ��ж�ȡһ������b
			if (b!=-1&&b!=-2&&b!=0&&b!=1)
			{
				sDB[lines].S[i]=b;
				i++;			
			}
			//cout<<b<<"\t";
			//outfile	<<b<<" ";
		}
		sDB[lines].len =i;
		sDB[lines].id =lines;
		if (max<i)
		{
			max=i;
		}
		//outfile <<endl;
		//cout <<endl<<max<<endl;
		lines++;
		if (lines==77512)
		{
			cout <<lines<<endl;
			break;
		}
	}
	NumbS=lines;
}
void main()
{
	read_file();
	cout<<"input the minlen,maxlen:";
	//cin>>minlen>>maxlen;
	minlen=1,maxlen=200;
	cout <<minlen<<" , "<<maxlen <<endl;
	cout<<"input the mingap,maxgap:";
	//cin>>mingap>>maxgap;
	mingap=0,maxgap=200;
	cout <<mingap<<" , "<<maxgap <<endl;

	cout<<"input the minsup:";
	cin>>minsup;
	//minsup=900;
	cout <<minsup<<endl;

	DWORD starttime = GetTickCount();
	min_freItem();   //cout frequent items and store item[]
    Fre.resize(0);      // in
	int e;
	for(e = 0; e < nn; e++)    // each item
	{
		vector <int> P;
		vector <ISupSet> I;
		//int plen;
		//plen = P.size();
		P.resize(1);
		int val=eSet[e];
		P[0] = eSet[e];     // p[0] = eSet[e]		
		int support=	SizeOneSup(sDB, P, I);  //  compute support set I(P[0]) in sDB
		mineFre(support, sDB, P, I);    // mining all frequent pattern
	}
	DWORD endtime = GetTickCount();
	disp_Fre(Fre);
	transform(Fre);
	disp_AllFre(AllFre);
	cout<<"The number of frequent patterns:"<<Fre.size()<<endl;
	cout<< "Time-consuming is : " << endtime-starttime << "ms." <<endl;
	cout<< "The number of calculation: " <<compnum<<endl;
}

