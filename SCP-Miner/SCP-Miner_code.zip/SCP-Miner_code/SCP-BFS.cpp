#include <map>
#include <set>
#include <vector>
#include <string>
#include <iostream>
#include <stdlib.h>
#include <windows.h>
#include <fstream>
#include <queue>
using namespace std;

#define K 4000   //The sequence number of sequence database
#define M 100   //The length of pattern
#define N 60 //The length of sequence
struct seqdb
{
	int id;	// sequence id
	char S[N]; // sequence
};			   // sequence database

#define sigmasize 4
char sigma[sigmasize]={'A','C','G','T'}; //inp
char flag[sigmasize] = {0};
struct percharsequence
{
	int len;
	vector<int> store;
};
vector<percharsequence> SeqDB[sigmasize][2]; 
/*struct each_char_in_sequence
{
	int len;
	vector <int> store;
};*/
struct incomplete_nettree
{
	string name;
	float pos_sup;
	vector<percharsequence> intree[2];
};
vector<int> len_seq[2];

int sequence_num[2] = {0, 0}; 
float density, minsup;
int countflag=0,need_num=0;

struct sorted_queue 
{
	string name; 
	float CR;	
	float pos_sup;
	friend bool operator<(sorted_queue a, sorted_queue b) 
	{
		return a.CR > b.CR;
	}
};

void calculate_intree(vector<int> &ic_ntree, vector<int> &next_level, int position, int sid, int lab)
{
	int size = ic_ntree.size();
	int len = next_level.size();
	vector<int> &store = SeqDB[position][lab][sid].store; 
	int ch_size = store.size();
	int k = 0;
	for (int j = 0; j < size; j++)
	{
		int parent = ic_ntree[j];
		int child;
		for (; k < ch_size; k++)
		{
			child = store[k];
			if (child > parent)
			{
				next_level.push_back(child); 
				k++;
				break;
			}
		}
		if (k == ch_size) 
			break;
	}
	len = next_level.size();
}
void displaytop(priority_queue<sorted_queue> topk)
{
	int len = topk.size();

	while (!topk.empty())
	{
		cout << topk.top().name << "\t" << topk.top().CR << endl;
		topk.pop();
	}
}
float other_level(incomplete_nettree &sub_pattern, int position, incomplete_nettree &pattern, int lab)
{
	float sup_number = 0;
	float sup_rate;
	pattern.intree[lab].clear();
	for (int sid = 0; sid < sequence_num[lab]; sid++)
	{
		float occnum = 0;
		float den = 0;
		float current_len = len_seq[lab][sid];
		percharsequence atree;
		calculate_intree(sub_pattern.intree[lab][sid].store, atree.store, position, sid, lab);
		atree.len = atree.store.size();
		occnum = atree.len;
		pattern.intree[lab].push_back(atree);
		if (current_len > 0)
		{
			den = occnum / (current_len);
			if (den > density)
			{
				sup_number++;
			}
		}
	}
	sup_rate = sup_number / sequence_num[lab];
	return sup_rate;
}

float first_level(int position, incomplete_nettree &pattern, int lab)
{
	float sup_number = 0;
	float sup_rate;
	for (int sid = 0; sid < sequence_num[lab]; sid++)
	{
		vector<int> storeS;
		storeS = SeqDB[position][lab][sid].store;
		pattern.intree[lab] = SeqDB[position][lab];
		float occnum = 0;
		float den = 0;
		float current_len = len_seq[lab][sid];
		occnum = pattern.intree[lab][sid].store.size();
		if (current_len > 0)
		{
			den = occnum / (current_len); 
			if (den > density)
			{
				sup_number++;
			}
		}
	}
	sup_rate = sup_number / sequence_num[lab];
	return sup_rate;
}
void dealingfirstlevel( //incomplete_nettree &current_pattern, sorted_queue &current_pat,
	priority_queue<sorted_queue> &top_ps, queue<incomplete_nettree> &entree, int &count)
{
	incomplete_nettree current_pattern;
	sorted_queue current_pat;
	for (int i = 0; i < sigmasize; i++)
	{
		need_num++;
		current_pattern.name = sigma[i];
		current_pat.name = sigma[i];
		current_pattern.pos_sup = current_pat.pos_sup = first_level(i, current_pattern, 0); 
		float neg_sup = first_level(i, current_pattern, 1);		
		current_pat.CR = current_pat.pos_sup - neg_sup;
		if (current_pat.pos_sup <= 0)
		{
			flag[i] = 0;
			continue;
		}
		else
		{
			flag[i] = 1;
			countflag++;
		}
		top_ps.push(current_pat);	 
		entree.push(current_pattern); 
		count++;
		if (top_ps.size() > minsup) 
		{
			top_ps.pop();
		}
	}
}

void Topk(priority_queue<sorted_queue> &top_ps)
{
	int lenofpattern, cur_len_pattern;
	int i, count = 0;
	sorted_queue sub_pat, current_pat, tmp_pat,lowest_pat;
	int NOcandp = 0;
	int maxsize = 0;

	queue<incomplete_nettree> entree; 
	dealingfirstlevel(top_ps, entree, count);
	NOcandp += sigmasize;
	maxsize = entree.size();
	cur_len_pattern = 1;
	incomplete_nettree sub_pattern, current_pattern;

	while (!entree.empty())
	{
		current_pattern.intree[0].clear();
		current_pattern.intree[1].clear();
		sub_pattern = entree.front();
		entree.pop();
		//NOcandp += sigmasize;
		lowest_pat=top_ps.top ();
		int size_t=top_ps.size ();
		if (sub_pattern.pos_sup <= 0 ||(size_t >= minsup && sub_pattern.pos_sup <= lowest_pat.CR))  //wyh
		{
			continue;
		}
		NOcandp += countflag;
		for (i = 0; i < sigmasize; i++)
		{
			if (flag[i] == 0)
			{
				continue;
			}
			need_num++;
			current_pattern.name = sub_pattern.name + sigma[i];
			lenofpattern = current_pattern.name.length();
			if (cur_len_pattern < lenofpattern)
			{
				cur_len_pattern++;
			}
			current_pat.name = sub_pattern.name + sigma[i];
			current_pattern.pos_sup = current_pat.pos_sup = other_level(sub_pattern, i, current_pattern, 0); 
			tmp_pat = top_ps.top();
			count = top_ps.size();
			if ((current_pat.pos_sup <= 0) || (count >= minsup && current_pat.pos_sup <= tmp_pat.CR)) 
			{
			}
			else
			{
				float neg_sup = other_level(sub_pattern, i, current_pattern, 1); 
				current_pat.CR = current_pat.pos_sup - neg_sup;
				if ((current_pat.CR > tmp_pat.CR) || (count < minsup && current_pat.CR > 0)) 
				{
					top_ps.push(current_pat); 
					count++;
					if (top_ps.size() > minsup) 
					{
						top_ps.pop();
					}
				}
				entree.push(current_pattern); 
				int entree_size = entree.size();
				if (maxsize < entree_size)
				{
					maxsize = entree_size;
				}
			}
		}
	}
	cout << "����TOPK�������" << endl;
	cout << "���ù������������ʽ��������" << NOcandp << "����ѡģʽ!\n"
		 << endl;
	cout<<"��Ҫ����ĺ�ѡģʽ������"<<need_num<<endl;
	cout << "������󳤶�Ϊ��" << maxsize << endl;
}

void disp(vector<int> &store)
{
	int len = store.size();
	for (int pos = 0; pos < len; pos++)
		cout << store[pos] << "\t";
	cout << endl
		 << endl;
}

void store_into_vec(seqdb sDB[2][K], int lab)
{
	int sid;
	for (sid = 0; sid < sequence_num[lab]; sid++)
	{
		percharsequence temp[sigmasize];
		string ss;
		percharsequence current_sequence;
		current_sequence.len = strlen(sDB[lab][sid].S);
		len_seq[lab].push_back(current_sequence.len);
		ss = sDB[lab][sid].S;
		for (int i = 0; i < current_sequence.len; i++)
		{
			//if (ss[i]>='a'&&ss[i]<='z')
			//ss[i]-=32;
			for (int j = 0; j < sigmasize; j++)
			{
				if (ss[i] == sigma[j])
				{
					temp[j].store.push_back(i);
					break;
				}
			}
		}
		for (i = 0; i < sigmasize; i++)
		{
			temp[i].len = temp[i].store.size();
			SeqDB[i][lab].push_back(temp[i]);
		}
	}
}
seqdb sDB0[K], sDB[2][K];
void read_file()
{
	FILE *fp=NULL;
	//fstream file;
	string buff;
	char p[20];
	cout << "������Ҫ������ļ�����" << endl; 
	fp=fopen("inp.txt","r+");
	int i = 0;
	while (fscanf(fp,"%s",sDB0[i].S )!= EOF)
	{
		i++;
	}
	fclose(fp);
	int filetype = 0;
	if (filetype == 1)
	{
		for (int line = 0; line < i; line++) 
		{
			if (sDB0[line].S[0] == '1')
			{
				strcpy(sDB[0][sequence_num[0]].S, sDB0[line].S + 1);
				sequence_num[0]++;
			}
			else if (sDB0[line].S[0] == '2')
			{
				strcpy(sDB[1][sequence_num[1]].S, sDB0[line].S + 1);
				sequence_num[1]++;
			}
		}
	}
	else
	{
		for (int line = 0; line < i; line++) //�����зֱ����sDB1  sDB2
		{
			if(line < i/2)             
			{
				strcpy(sDB[0][sequence_num[0]].S, sDB0[line].S);
				sequence_num[0]++;
			}
			else
			{
				strcpy(sDB[1][sequence_num[1]].S, sDB0[line].S);
				sequence_num[1]++;
			}
		}
	}
	cout << "�������и�����" << sequence_num[0] << endl; //output the sequence number of sDB1
	cout << "�������и�����" << sequence_num[1] << endl; //output the sequence number of sDB2
	store_into_vec(sDB, 0);
	store_into_vec(sDB, 1);
}

int main()
{
	read_file();
	//cout<<sDB[1][0].S;
	cout << "input the value of K:" << endl;
	//cin>>minsup;
	minsup = 10;
	cout << "input the value of density:" << endl;
	//cin>>density;
	density = 0.075;
	priority_queue<sorted_queue> vec;
	DWORD begintime = GetTickCount();
	Topk(vec);
	DWORD endtime = GetTickCount();
	int i = 0;
	if (vec.empty())
		cout << "û�жԱ�ģʽ!" << endl;
	cout << "���ھ����" << vec.size() << "��ģʽ���ھ���Ϊ��" << endl;
	while (!vec.empty())
	{
		cout << i << "\t" << vec.top().name << "\t" << vec.top().CR << endl;
		i++;
		vec.pop();
	}
	cout << endl;
	//vec.clear();
	cout << "The time-consuming:" << endtime - begintime << "ms. \n";
	cout << endl;
	return 0;
}
