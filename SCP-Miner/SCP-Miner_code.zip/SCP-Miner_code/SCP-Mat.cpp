#include <map>
#include <set>
#include <vector>
#include <string>
#include <iostream>
#include <stdlib.h>
#include <windows.h>
#include <fstream>
#include <queue>
#include <cmath>
using namespace std;

#define K 4000   //The sequence number of sequence database
#define M 100   //The length of pattern
#define N 60 //The length of sequence
#define MAXLENP 100
#define BUFFER 1000

#define sigmasize 4
char sigma[sigmasize]={'A','C','G','T'}; //inp

float precision = 0.000001;

struct superpattern
{
	int size[sigmasize];
};

struct seqdb
{
	int id;	// sequence id
	char S[N]; // sequence
};			   // sequence database

char flag[sigmasize] = {0};
int countflag = 0;
vector<int> len_seq[2];

int sequence_num[2] = {0, 0};
float density, minsup;
int pruned = 0;

struct sorted_queue 
{
	string name; // first
	float CR;	// second
	float pos_sup;
	friend bool operator<(sorted_queue a, sorted_queue b) 
	{
		return a.CR > b.CR;
	}
};
struct squeue 
{
	string name; // first
	float CR;	// second
	float pos_sup;
};

struct sorted_CP_D 
{
	string name;   
	int len;	  
	float CR;	 
	float pos_sup; 
};

struct CP 
{
	string name; // first
	float CR;	// second
};

seqdb sDB0[K], sDB[2][K];

int HalfSearch(vector<sorted_CP_D> &st, int begin, int end, sorted_CP_D &value)
{
	int mid = (begin + end) / 2;
	for (; begin < end; mid = (begin + end) / 2)
	{
		if (value.CR > st[mid].CR)
		{
			begin = mid + 1;
		}
		else if (value.CR < st[mid].CR)
		{
			end = mid - 1;
		}
		else if (fabs(value.CR - st[mid].CR) < precision)  
		{
			break;
		}
	}
	if (fabs(value.CR - st[mid].CR) < precision)  
		return mid;
	else if (value.CR > st[end].CR)
		return end + 1;
	else if (value.CR < st[begin].CR)
		return begin;
}
void OrderAInsert(vector<sorted_CP_D> &st, sorted_CP_D &value)
{
	int len = st.size();
	if (len == 0)
	{
		st.push_back(value);
		return;
	}
	int begin = 0, end = len;
	int position = HalfSearch(st, begin, end - 1, value);
	st.insert(st.begin() + position, value);
}

void checking_density(float *occs, float *sup_number, int &lens, int &lenp)
{
	for (int k = 0; k < sigmasize; k++)
	{
		float den = occs[k] / lens;
		if (den > density)
		{
			sup_number[k]++;
		}
	}
}
void dealingCR(sorted_queue *current_pat, sorted_CP_D *superp, float *sup_number, int &lab)
{
	int k;
	if (lab == 0)
	{
		for (k = 0; k < sigmasize; k++)
		{
			current_pat[k].pos_sup = sup_number[k] / sequence_num[lab];
			superp[k].pos_sup = current_pat[k].pos_sup;
		}
	}
	else
	{
		for (k = 0; k < sigmasize; k++)
		{
			current_pat[k].CR = current_pat[k].pos_sup - sup_number[k] / sequence_num[lab];
			superp[k].CR = current_pat[k].CR;
		}
	}
}
void storefirst(priority_queue<sorted_queue> &top_ps, sorted_queue *current_pat,
				vector<sorted_CP_D> &entree, sorted_CP_D *superp)
{
	for (int k = 0; k < sigmasize; k++)
	{
		if (current_pat[k].pos_sup > 0) //wyh
		{
			flag[k] = 1;
			countflag++;
			if (current_pat[k].CR > 0)
				top_ps.push(current_pat[k]);
			OrderAInsert(entree, superp[k]);
			if (top_ps.size() > minsup) 
			{
				top_ps.pop();
			}
		}
		else
			flag[k] = 0;
	}
}
void storeother(priority_queue<sorted_queue> &top_ps, sorted_queue *current_pat,
				vector<sorted_CP_D> &entree, sorted_CP_D *superp, int &maxsize)
{
	sorted_queue tmp_pat;
	for (int k = 0; k < sigmasize; k++)
	{
		if (flag[k] == 0)
			continue;
		int count = top_ps.size();
		if (count > 0)
		{
			tmp_pat = top_ps.top();
		}
		else
		{
			tmp_pat.CR = 0;
			tmp_pat.name = "";
			tmp_pat.pos_sup = 0;
		}
		if (current_pat[k].pos_sup <= 0 || (count >= minsup && current_pat[k].pos_sup <= tmp_pat.CR)) //wyh
		{
			pruned++;
		}
		else
		{
			if ((current_pat[k].CR > tmp_pat.CR) || (count < minsup && current_pat[k].CR > 0)) //wyh
			{
				top_ps.push(current_pat[k]);
				if (top_ps.size() > minsup)  
				{
					top_ps.pop();
				}
			}
			OrderAInsert(entree, superp[k]);
			int entree_size = entree.size();
			if (maxsize < entree_size)
			{
				maxsize = entree_size;
			}
		}
	}
}
void dealingfirstlevel(priority_queue<sorted_queue> &top_ps, vector<sorted_CP_D> &entree, int &count)
{
	sorted_queue current_pat[sigmasize];
	sorted_CP_D superp[sigmasize];
	count = sigmasize;
	int k;
	for (int i = 0; i < sigmasize; i++)
	{
		current_pat[i].name = sigma[i];
		superp[i].name = sigma[i];
		superp[i].len = 1;
	}
	for (int lab = 0; lab < 2; lab++)
	{
		float sup_number[sigmasize] = {0};
		for (int sid = 0; sid < sequence_num[lab]; sid++)
		{
			float occs[sigmasize] = {0};
			int lens = strlen(sDB[lab][sid].S);
			for (int pos = 0; pos < lens; pos++)
			{
				for (k = 0; k < sigmasize; k++)
				{
					if (sDB[lab][sid].S[pos] == sigma[k])
					{
						occs[k]++;
					}
				}
			}
			int lenp = 1;
			checking_density(occs, sup_number, lens, lenp); 
		}
		dealingCR(current_pat, superp, sup_number, lab);
	}
	storefirst(top_ps, current_pat, entree, superp);
}

int matching(char *s, string p_pattern)
{
	char p[MAXLENP];
	strcpy(p, p_pattern.c_str());

	int lens = strlen(s);
	int lenp = strlen(p);
	int nettree[BUFFER][MAXLENP] = {0};
	int level_len[MAXLENP] = {0};
	int i, j;
	int count = 0;
	if (strlen(p) == 1)
	{
		for (int i = 0; i < strlen(s); i++)
		{
			if (s[i] == p[0])
			{
				count++;
			}
		}
		return count;
	}
	//convert (p,sigma,sigmasize,sigmaorder);
	for (i = 0; i < lens; i++)
	{
		int hasbeenadded = 0;
		if (p[0] == s[i]) 
		{
			hasbeenadded = 1;
			int position = level_len[0];
			position = position % BUFFER;
			if (level_len[0] - level_len[lenp - 1] > BUFFER - 1) 
			{
				cout << "Overflow!!!\nThe buffer is too small.\n";
				return -1;
				//break;
			}
			nettree[position][0] = i;
			level_len[0]++;
		}
		for (j = 1; j < lenp; j++)
		{
			if (p[j] == s[i])
			{
				int flag = 0;
				if (p[j] == p[j - 1] && hasbeenadded) //&&nettree[pos-1][j-1]==i)
				{
					flag = 1;
				}
				if (level_len[j - 1] - flag > level_len[j])
				{
					hasbeenadded = 1;
					int position = level_len[j];
					position = position % BUFFER;
					nettree[position][j] = i;
					level_len[j]++;
					if (j == lenp - 1) 
					{
						count++;
						int pos = level_len[j] - 1;
						pos = pos % BUFFER;
					}
				}
				else 
					hasbeenadded = 0;
			}
		}
	}

	return count;
}

void Topk(priority_queue<sorted_queue> &top_ps)
{
	int count = 0;
	sorted_queue sub_pat;
	int maxsize = 0;
	int NOcandp = 0;

	vector<sorted_CP_D> entree; 

	cout << "Processing the patterns with length 1...\n";

	dealingfirstlevel(top_ps, entree, count);
	NOcandp += sigmasize;
	maxsize = entree.size();
	int lenpc = 1;
	sorted_CP_D sub_pattern;
	sorted_queue current_pat[sigmasize];
	sorted_CP_D superp[sigmasize];
	int lenp;
	while (!entree.empty())
	{
		int sizeentree = entree.size();
		sub_pattern = entree[sizeentree - 1];
		entree.pop_back();

		sorted_queue lowest_pat;
		int size_t = top_ps.size();
		if (size_t > 0)
		{
			lowest_pat = top_ps.top();
		}
		else
		{
			lowest_pat.CR = 0;
			lowest_pat.pos_sup = 0;
			lowest_pat.name = "";
		}

		if (sub_pattern.pos_sup <= 0 || (size_t >= minsup && sub_pattern.pos_sup <= lowest_pat.CR)) //wyh
		{
			pruned++;
			continue;
		}
		NOcandp += countflag;
		lenp = sub_pattern.name.length() + 1;
		if (lenpc < lenp)
		{
			lenpc++;
		}

		for (int lab = 0; lab < 2; lab++)
		{
			float sup_number[sigmasize] = {0};
			for (int sid = 0; sid < sequence_num[lab]; sid++)
			{
				float occs[sigmasize] = {0};
				int lens = strlen(sDB[lab][sid].S);
				for (int occ_num = 0; occ_num < sigmasize; occ_num++)
				{
					if (flag[occ_num] == 1)
					{
						current_pat[occ_num].name = sub_pattern.name + sigma[occ_num];
						superp[occ_num].name = sub_pattern.name + sigma[occ_num];
						superp[occ_num].len = superp[occ_num].name.length();
						occs[occ_num] = matching(sDB[lab][sid].S, current_pat[occ_num].name);
					}
				}
				//matchingwithsub(sDB[lab][sid].S, sub_pattern.name, occs);
				int lenp = sub_pattern.name.length() + 1;
				checking_density(occs, sup_number, lens, lenp); 
			}
			dealingCR(current_pat, superp, sup_number, lab);
		}

		storeother(top_ps, current_pat, entree, superp, maxsize);
	}

	cout << "����TOPK�������" << endl;
	cout << "����Matching��ʽ��������" << NOcandp << "����ѡģʽ!\n"
		 << endl;
	cout << "������󳤶�Ϊ��" << maxsize << endl;
	cout << "��ջ�ټ�ⷽʽ��֦����ģʽ������" << pruned << endl;
}

void disp(vector<int> &store)
{
	int len = store.size();
	for (int pos = 0; pos < len; pos++)
		cout << store[pos] << "\t";
	cout << endl
		 << endl;
}

void read_file()
{
	FILE *fp=NULL;
	//fstream file;
	string buff;
	char p[20];
	cout << "������Ҫ������ļ�����" << endl; 
	fp=fopen("psjgall.txt","r+");
	int i = 0;
	while (fscanf(fp,"%s",sDB0[i].S )!= EOF)
	{
		i++;
	}
	fclose(fp);
//	file.close();
	//filetype=1;
	//filetype=0;	
	int filetype = 1;
	if (filetype == 1)
	{
		for (int line = 0; line < i; line++) 
		{
			if (sDB0[line].S[0] == '1')
			{
				strcpy(sDB[0][sequence_num[0]].S, sDB0[line].S + 1);
				sequence_num[0]++;
			}
			else if (sDB0[line].S[0] == '2')
			{
				strcpy(sDB[1][sequence_num[1]].S, sDB0[line].S + 1);
				sequence_num[1]++;
			}
		}
	}
	else
	{
		for (int line = 0; line < i; line++) 
		{
			if(line < i/2)            
			{
				strcpy(sDB[0][sequence_num[0]].S, sDB0[line].S);
				sequence_num[0]++;
			}
			else
			{
				strcpy(sDB[1][sequence_num[1]].S, sDB0[line].S);
				sequence_num[1]++;
			}
		}
	}
	cout << "�������и�����" << sequence_num[0] << endl; //output the sequence number of sDB1
	cout << "�������и�����" << sequence_num[1] << endl; //output the sequence number of sDB2
	//store_into_vec(sDB, 0);
}

int main()
{
	read_file();
	//cout<<sDB[1][0].S;
	cout << "input the value of K:" << endl;
	//cin>>minsup;
	minsup = 10;
	cout << "input the value of density:" << endl;
	//cin>>density;
	density = 0.075;
	//vector <pattern> vec;
	priority_queue<sorted_queue> vec;
	DWORD begintime = GetTickCount();
	Topk(vec);
	DWORD endtime = GetTickCount();
	int i = 0;
	while (!vec.empty())
	{
		cout << i << "\t" << vec.top().name << "\t" << vec.top().CR << endl;
		i++;
		vec.pop();
	}
	cout << endl;
	//vec.clear();
	cout << "The time-consuming:" << endtime - begintime << "ms. \n";
	cout << endl;
	return 0;
}
