#include <map>
#include <set>
#include <vector>
#include <string>
#include <iostream>
#include <stdlib.h>
#include <windows.h>
#include <fstream>
#include <io.h>  
#include <time.h>

using namespace std;
#define K 6000    //The sequence number of sequence database
#define M 1000   //The length of pattern
#define N 200000  //The length of sequence
struct node         //nettree node
{
	int name;     //The corresponding position of node in sequence
	int min_leave,max_leave;   //The position of maxinum and mininum leave nodes
	vector <int> parent;     //The position set of parents
	vector <int> children;  //The position set of children
	bool used;      //true is has used, false is has not used
	bool toleave;  //true is can reach leaves, false is not
};
struct seqdb                 
{
	int id;                  // sequence id
	char S[N];              // sequence
} sDB[K];                 // sequence database
struct occurrence   //occurrence
{
	vector <int > position;
};
struct sub_ptn_struct   //a[0,3]c => start[min,max]end
{
	char start,end;		
	int min,max;
};
int NumbS;
int store1;
int minlen,maxlen;   //length constraint
int mingap,maxgap; //gap constraint
char S[N];  //sequence
int minsup;  
int ptn_len;  
sub_ptn_struct sub_ptn[M];  //pattern p[i]
vector <string> freArr_item ;  //store frequent patterns
vector <string> candidate; //store candidate patterns
vector <string> fre_max;   //store  Maximal frequent 
vector<string> files;         //store File name under data folder

string path_name ="E://�о���ʵ����//����϶//writepaper//ʵ����//dataset//";
string file_name = "INP";
string path = path_name+file_name;


int compnum = 0, frenum = 0;  //compute number and frequents number
vector <occurrence> store;
int h=0;
void deal_range(string pattern)      
//put sub-pattern "a[1,3]b" into sub_ptn and sub_ptn.start=a��sub_ptn.end=b, sub_ptn.min=1��sub_ptn.max=3
{
	ptn_len=0;
	memset(sub_ptn, 0, sizeof(sub_ptn_struct));
	char p[M];
	strcpy(p,pattern.c_str()); 
	if (strlen(p)==1)
	{
		sub_ptn[ptn_len].start = p[0];
		sub_ptn[ptn_len].max =sub_ptn[ptn_len].min=0;
	}
	for(int i=0;i<strlen(p)-1;i++ )
	{
		sub_ptn[ptn_len].start =p[i];
		sub_ptn[ptn_len].end =p[i+1];
		sub_ptn[ptn_len].min=mingap;	
		sub_ptn[ptn_len].max=maxgap;
		ptn_len++;
	}
}

void min_freItem()
{
	 map <string, int > counter;
	 string mine;
	 for(int t = 0; t < K; t++)
	 {
		strcpy(S,sDB[t].S);
		for(int i=0;i<strlen(S);i++)
		{
			mine=S[i];
			counter[mine]++;			
		}	 
	 }
	 for (map <string,int >::iterator the_iterator = counter.begin (); the_iterator!= counter.end (); )
	 {
		 if (the_iterator->second < minsup)
		 {
			map <string, int >::iterator tmp = the_iterator;
			++tmp;
			counter.erase (the_iterator);
			the_iterator = tmp;
		 } 
		 else
		 {
			 freArr_item.push_back(the_iterator->first);  //add to freArr[0]
			 ++the_iterator;
		 }
	}
}


void createnettree_length(vector <node> *nettree)
{
	for (int i=0;i<ptn_len+1;i++)
		nettree[i].resize (0);  //initialize nettree
	int *start;
	start=new int[ptn_len+1];
	for (i=0;i<ptn_len+1;i++)
		start[i]=0;
	for (i=0;i<strlen(S);i++)
	{
		node anode;
		anode.name =i;
		anode.parent.resize (0);
		anode.children .resize (0);
		anode.max_leave=anode.name;
		anode.min_leave=anode.name;
		anode.used =false;   
		//store root
		if (sub_ptn[0].start ==S[i])
		{
			int len=nettree[0].size ();
			nettree[0].resize (len+1);
			anode.toleave =true;
			nettree[0][len]=anode;			
		}
		for (int j=0;j<ptn_len;j++)
		{
			if (sub_ptn[j].end==S[i])
			{
				//Look for parents from the layer above.
				int prev_len=nettree[j].size ();
				if (prev_len==0)
				{
					break;
				}
				//update start
				for (int k=start[j];k<prev_len;k++)
				{
					if (i-nettree[j][k].name -1>sub_ptn[j].max )
					{
						start[j]++;  // greater than max, cursor moves rearward
					}
				}
				//compare gap constraint
				if (i-nettree[j][prev_len-1].name -1>sub_ptn[j].max)
				{
					continue;
				}
				if (i-nettree[j][start[j]].name -1<sub_ptn[j].min)
				{
					continue;
				}
	
				int len=nettree[j+1].size ();
				nettree[j+1].resize (len+1);
				anode.toleave =true;
				nettree[j+1][len]=anode;
				for (k=start[j];k<prev_len;k++)
				{
					if (i-nettree[j][k].name -1<sub_ptn[j].min )
					{
						break;
					}
					//Meet gap constraint
					//builds the relationship between father and son
					int nc=nettree[j][k].children .size ();
					nettree[j][k].children.resize (nc+1);
					nettree[j][k].children [nc]=len;
					int np=nettree[j+1][len].parent .size ();
					nettree[j+1][len].parent.resize (np+1);
					nettree[j+1][len].parent [np]=k;
				}
			}
		}
	}
	delete []start;
}
void update_nettree(vector <node> *nettree)
{
	for (int i=ptn_len-1;i>=0;i--)
	{
		for(int j=nettree[i].size ()-1;j>=0;j--)
		{
			bool flag=true;
			int size=nettree[i][j].children.size ();
			for (int k=0;k<size;k++)
			{
				int child=nettree[i][j].children[k];
				if(k==0)
				{
					nettree[i][j].min_leave=nettree[i+1][child].min_leave;
				}
				if(k==size-1)
				{
					nettree[i][j].max_leave=nettree[i+1][child].max_leave;
				}
				if (nettree[i+1][child].used ==false)
				{
					flag=false;					
				}
			}
			//For nodes that do not arrive at leave,marking for the used=true
			nettree[i][j].used =flag;
			if(flag==true)
			{
				nettree[i][j].max_leave=nettree[i][j].name;
				nettree[i][j].min_leave=nettree[i][j].name;
				nettree[i][j].toleave = false;
			}
		}
	}
}


struct nodep
{
	int level,position;
};
int bts(int j, int  child, int root, vector <node> *nettree, occurrence & occin,occurrence & occ,int & ls, nodep * recovery)//int *  occin, int *occinname)	//BackTracking Strategy 
{ 

    if (j<=0)
		return -1;
	if (j>ptn_len)
	{
		return 1;
	}
	else 
	{
			int parent=occin.position  [j-1];    //The position of the parent in nettree
			int cs=nettree[j-1][parent].children.size ();   //The number of children of the current node
			for (int t=cs-1;t>=0;t--)
			{
			    child=nettree[j-1][parent].children[t];    //The position of the most left child
				if (nettree[j][child].used == true)
					continue;
				int a1=nettree[j][child].max_leave - root+1;
				int b1=nettree[j][child].min_leave - root+1;	
				if (nettree[j][child].used ==false&&
					((a1<=maxlen&&a1>=minlen)||(b1>=minlen&&b1<=maxlen)))
				{
					occin.position  [j]=child;			//
					//occinname[j]=nettree[j][occin[j]].name ;
					int value=nettree[j][child].name;
					occ.position [j]=value ;

					nettree[j][child].used=true;
					nettree[j][child].toleave =false;
					recovery[ls].level =j;
					recovery[ls].position =child;
					ls++;
					int ret=bts(j+1, child, root, nettree, occin,occ,ls,recovery);//,occinname);
					if (ret==1)
						break;
				}
			}
			if (t==-1)		// cannot find it
			{
				h++;
				int ret=bts(j-1, child, root, nettree, occin,occ,ls,recovery);//, occinname);// backtracking
				if (ret==-1)
					return -1;
				else
					return 1;
			}
			return 1;
	}
}

void nonoverlength_back(int rest)    
{
	vector <node> *nettree;
	nettree=new vector <node> [ptn_len+1];
	int *nodenumber;
	nodenumber=new int [ptn_len+1];
	createnettree_length(nettree);
	update_nettree(nettree);
	//dipaynettree(nettree);
	nodep * recovery;
	recovery=new nodep[100*ptn_len];
	store1=0;
	store.resize (0);
	for (int position=nettree[0].size ()-1;position>=0;position--)
	{
		if (nettree[0][position].used ==true)
			continue;
		if (nettree[0][position].toleave ==false)
		{
			// false is cannot reach root
			continue;
		}
		int root=nettree[0][position].name;
		//cout<<"root"<<root<<endl;
		//cout<<"nettree[0][position].max_leave"<<nettree[0][position].max_leave<<endl;
        //cout<<"nettree[0][position].min_leave"<<nettree[0][position].min_leave<<endl;
		int a=nettree[0][position].max_leave-root+1;
		int b=nettree[0][position].min_leave- root+1;
		//cout<<"a="<<a<<";b="<<b<<endl;
		if (!( (minlen<=a&&a<=maxlen)||(minlen<=b&&b<=maxlen)))  //does not meet the length constraint
		{
			
			nettree[0][position].used =true;
			nettree[0][position].toleave =false;
			continue;
		}
		//occin[0]=position;
		//occinname[0]=nettree[0][occin[0]].name ;
        occurrence occ;//////////////////////////////////////////////
		occurrence occin;  
		occ.position .resize (ptn_len+1);///////////////////////////////////////
		occin.position .resize (ptn_len+1);
		occin.position [0]=position;
		occ.position [0]=nettree[0][position].name ;
		nettree[0][position].used =true;
		nettree[0][position].toleave =false;
		//Looking down for the most right child using backtracking strategy;
		int j=1,ret=-1;
		int ls=0;
		ret=bts (j, position, root, nettree, occin,occ,ls,recovery);//, occinname);	//BackTracking Strategy
		
		if (ret==1)
		{
			

			int len=store.size ();
			store.resize (len+1);
			store[len]=occ;
			store1++;
			//updatenettree_length_pc(nettree,occin);
			//displaynettree(nettree);

		}
		else
		{
			for (int jj=0;jj<ls;jj++)
			{
				int level=recovery[jj].level;
				int pos=recovery[jj].position ;
				nettree[level][pos].used=false;
				nettree[level][pos].toleave =true;
			}
		}
		memset(&occin,0,sizeof(occin)); 

		
	}
END:
	delete []recovery;
	delete []nettree;
}

//compute support
int netGap(string p,int reset)
{
	deal_range(p);
	if(ptn_len+1 > strlen(S))
	{
		int num=0;
		return num;
	}
	nonoverlength_back(reset);
	return store1;
}
void read_file()
{
	fstream file;
	string buff;
	file.open("DataSet/DNA1.txt",ios::in);   //open sequence file
	int i=0;
	while(getline(file, buff))
	{
		strcpy(sDB[i].S, buff.c_str());
		i++;
	}
	NumbS = i;
	// print sequence database
	cout << "sDB and min_sup are as follows : " << endl;
	for(int t = 0; t < NumbS; t++)
	{
		sDB[t].id = t + 1;
		cout << "\t(" << sDB[t].id << ",(" << sDB[t].S << "))" << endl;
	}
}

void deapth_min(string str){
	//cout<<str<<endl;	
	bool flag_pro = false;
	bool flag_str = true;     // judge  str is max_free
	string cand_suf;
	for(int i=0;i<freArr_item.size();i++)
	{	
		int occnum=0;	
		cand_suf = str+freArr_item[i];  // str add item
		int reset = 0;
		for(int t = 0; t < K; t++)
		{
			reset = minsup - occnum;
			if(strlen(sDB[t].S) > 0)
			{
				strcpy(S,sDB[t].S);
				occnum += netGap(cand_suf,reset);    //compute the support of cand_suf
			}
		}
		if(occnum >= minsup)
		{
			flag_str = false;
			deapth_min(cand_suf);             //if cand_suf is freArr continue deapth_min
			//freArr[f_level].push_back(p);
		}
		else if(i==freArr_item.size()-1&&flag_str){  //�����Ը�ģʽ��Ϊǰ׺�ĳ�ģʽ����Ƶ��
			int num=0;
			bool flag = true;
			for(int j=0;j<freArr_item.size();j++)  //�ж���Ϊ��׺���ɵĳ�ģʽ�Ƿ�Ƶ�� 
			{	
				int occnum=0;
				int reset = 0;
				string cand_pro ;
				cand_pro = freArr_item[j]+str;
				
				for(int t = 0; t < K; t++)
				{
					reset = minsup - occnum;
					if(strlen(sDB[t].S) > 0)
					{
						strcpy(S,sDB[t].S);
						occnum += netGap(cand_pro,reset);
					}
				}
				if(occnum >= minsup)
				{	
					flag = false; 
					break;
				}				
			}
			if(flag)//&&num==freArr_item.size()-1
			{
				fre_max.push_back(str);
			}
		}
		
	}
}


void max_miner_D(){
	for(int i=0;i<freArr_item.size();i++){
		string str = freArr_item[i];
		deapth_min(str);
	}
}
void getFiles()
{
	//string path ="E://�о���ʵ����//����϶//���ģʽ//DataSet//DNA1";
	//string path = "E://�о���ʵ����//����϶//���ģʽ//DataSet";//data folder 
    //�ļ����  
    long   hFile = 0;
    //�ļ���Ϣ������һ���洢�ļ���Ϣ�Ľṹ��  
    struct _finddata_t fileinfo;
    string p;//�ַ��������·��
    if ((hFile = _findfirst(p.assign(path).append("\\*").c_str(), &fileinfo)) != -1)//�����ҳɹ��������
    {
        do
        {
           
              files.push_back(p.assign(path).append("\/\/").append(fileinfo.name));
            
        } while (_findnext(hFile, &fileinfo) == 0);
        //_findclose������������
        _findclose(hFile);
    }
}

int main(int argc, const char *argv[])
{
	read_file();
	cout<<"Input mingap and maxgap:"<<endl;
	cin>>mingap>>maxgap;
	cout<<"Input minsup:"<<endl;
	cin>>minsup;
	minlen= 0;maxlen=3000;
	cout<<mingap<<"\t"<<maxgap<<"\t"<<minsup<<"\t"<< "endl;"<<endl;
	
	
	DWORD begintime=GetTickCount();
	min_freItem();
	max_miner_D();
	DWORD endtime=GetTickCount();
	
	
	for(int j=0;j<fre_max.size();j++){
		cout<<fre_max[j]<<"\t";
	}		
	cout<<"\n"<<endl;
	cout<<"The number of frequent patterns:"<<fre_max.size()<<endl;
	cout <<"The time-consuming:"<<endtime-begintime<<"ms. \n";

	time_t t = time(0); 
	char tmp[32]={NULL};
	strftime(tmp, sizeof(tmp), "%Y-%m-%d %H:%M:%S",localtime(&t)); 
	
	ofstream mcfile; //����������
	mcfile.open("result_file.txt",ios::app); //�����ļ�
	string s="DataSet/DNA1.txt";
	mcfile<<tmp<<"\t"<<s<<"\t"<<minsup<<"\t"<<"\t["<<mingap<<","<<maxgap<<"]\t"<<endtime-begintime<<"\t\t\t"<<fre_max.size()<<"\n";
	mcfile.close(); //�ر�

	ofstream maxfrefile;
	maxfrefile.open("result_fature.txt",ios::app);
	maxfrefile<<tmp<<"\t"<<s<<"\t"<<minsup<<"\t"<<"\t["<<mingap<<","<<maxgap<<"]\t"<<endtime-begintime<<"\t\t\t"<<fre_max.size()<<"\n";

	for(int k=0;k<fre_max.size();k++){
		maxfrefile<<fre_max[k]<<"\t";	
	}	
	maxfrefile<<"\n";
	maxfrefile.close();

	fre_max.clear();
	freArr_item.clear();
	return 0;
}