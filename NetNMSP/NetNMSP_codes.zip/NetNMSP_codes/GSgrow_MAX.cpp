#include <map>
#include <set>
#include <vector>
#include <string>
#include <iostream>
#include <stdlib.h>
#include <windows.h>
#include <fstream>
using namespace std;
#define K 600    //The sequence number of sequence database
#define M 100   //The length of pattern
#define N 20000  //The length of sequence
#define MAXLENP 100
#define BUFFER 1000
int sequence_num = 0;

//#define sigmasize 4
//char sigma[sigmasize]={'A','C','G','T'}; //inp
int sigmasize=0; 
char sigma[M];

struct node         //nettree node
{
	int name;     //The corresponding position of node in sequence
	int min_leave,max_leave;   //The position of maxinum and mininum leave nodes
	vector <int> parent;     //The position set of parents
	vector <int> children;  //The position set of children
	bool used;      //true is has used, false is has not used
	bool toleave;  //true is can reach leaves, false is not
};
struct seqdb                 
{
	int id;                  // sequence id
	char S[N];              // sequence
};                 // sequence database
seqdb sDB0[K], sDB[K];
struct percharsequence
{
	int len;
	vector<int> store;
};
vector<percharsequence> SeqDB[M]; //character is stored by position
struct sorted_incomplete_nettree
{
	string name;
	float pos_sup;
	vector<percharsequence> intree;
};
vector<int> len_seq;

char S[N];  //sequence
int minsup;  
int max_level=0;
vector <sorted_incomplete_nettree> *freArr;  //store frequent patterns

vector <string> * MaxFre;
//vector <sorted_incomplete_nettree> candidate; 
int compnum = 0, frenum = 0;  //compute number and frequents number


int mingap, maxgap;

void calculate_intree(vector<int> &ic_ntree, vector<int> &next_level, int position, int sid)
//ic_ntree��ʾsubpattern�Ĳ���������
//next_level��ʾcurrentpattern�Ĳ���������
//position��ʾsigma�еĵ�position���ַ�
{
	int size = ic_ntree.size();
	int len = next_level.size();
	vector<int> &store = SeqDB[position][sid].store; //��ʾ��position���ַ�ʵ�ʴ洢���
	int ch_size = store.size();
	int k = 0;
	for (int j = 0; j < size; j++)
	{
		int parent = ic_ntree[j];
		int child;
		for (; k < ch_size; k++)
		{
			child = store[k];
			if (child >= parent+mingap+1 )
			{
				if (child <= parent+maxgap+1 )
				{
					next_level.push_back(child); //��ǰ��Ϣ���д洢
					k++;

				}
				break;
			}
		}
		if (k == ch_size) //û���ˣ�������������ж�
			break;
	}
	len = next_level.size();
}

float other_level(sorted_incomplete_nettree &sub_pattern, int position, sorted_incomplete_nettree &pattern)
{
	//lab��ʾ������,poisition��ʾ���ڴ�����sigma �е�position���ַ�
	//sub_pattern��ʾ��ģʽ�Ĳ���������
	//pattern��ʾ���ɵĳ�ģʽ�Ĳ���������
	//int len=pattern.name .length ();
	pattern.intree.clear();
	float occnum = 0;
	for (int sid = 0; sid < sequence_num; sid++)
	//sid��ʾ���������п��е��±�
	{
		float current_len = len_seq[sid];
		//����sub_pattern�Ĳ��������������ɵ�ǰģʽ�Ĳ���������,������洢��result�У�
		percharsequence atree;
		calculate_intree(sub_pattern.intree[sid].store, atree.store, position, sid);
		atree.len = atree.store.size();
		occnum += atree.len;
		pattern.intree.push_back(atree);
	}
	//if(pattern.name == "aaaaa") cout<<"sup_rate = "<<	sup_rate <<endl;
	return occnum;
}

float first_level(int position, sorted_incomplete_nettree &pattern)
{
	float occnum = 0;
	//pattern.intree[lab] =SeqDB[lab];
	for (int sid = 0; sid < sequence_num; sid++)
	{
		vector<int> storeS;
		storeS = SeqDB[position][sid].store;
		pattern.intree = SeqDB[position];
		occnum += pattern.intree[sid].store.size();
	}
	return occnum;
}

void dealingfirstlevel( //incomplete_nettree &current_pattern, sorted_queue &current_pat,
	vector<sorted_incomplete_nettree> *freArr)
{
	//process the pattern  with length 1
	sorted_incomplete_nettree current_pattern;
	for (int i = 0; i < sigmasize; i++)
	{
		compnum++;
		current_pattern.name = sigma[i];
		current_pattern.pos_sup = first_level(i, current_pattern); //positive support rate
		if (current_pattern.pos_sup >= minsup) 
		{
			freArr[0].push_back(current_pattern);
			//MaxFre[0].push(current_pattern.name );
		}
	}
}

bool mineFre(sorted_incomplete_nettree &subp)
{
	bool flag=false;
	for(int e = 0; e < freArr[0].size(); e++)
	{
		sorted_incomplete_nettree cand;
		cand.name = subp.name + freArr[0][e].name;
		//cout<<cand.name<<"\t";
		compnum++;
		int position;
		for(int t = 0; t < sigmasize; t++)
		{
			if(freArr[0][e].name[0] == sigma[t])
			{
				position = t;
				break;
			}
		}
		/*if (cand.name=="ttatttt")
		{
			cout <<"t:";
			//for (int tmp=0;tmp<subp.intree[0].store.size ();tmp++)
			//{
			//	cout <<subp.intree[0].store[tmp]<<"\t";
			//}
			cout <<endl;
		}*/
		/*if (cand.name=="tta")
		{
			cout <<"tt:";
			for (int tmp=0;tmp<subp.intree[0].store.size ();tmp++)
			{
				cout <<subp.intree[0].store[tmp]<<"\t";
			}
			cout <<endl;
		}
		if (cand.name=="ttat")
		{
			cout <<"tta:";
			for (int tmp=0;tmp<subp.intree[0].store.size ();tmp++)
			{
				cout <<subp.intree[0].store[tmp]<<"\t";
			}
			cout <<endl;
		}
		if (cand.name=="ttatt")
		{
			cout <<"ttat:";
			for (int tmp=0;tmp<subp.intree[0].store.size ();tmp++)
			{
				cout <<subp.intree[0].store[tmp]<<"\t";
			}
			cout <<endl;
		}*/
		cand.pos_sup = other_level(subp, position, cand); 
		//cout<<"subp.name = "<<subp.name<<"\t"<<"cand.name = "<<cand.name<<endl;
		if(cand.pos_sup >= minsup)
		{
			flag=true;
			int level=cand.name .length ()-1;
			freArr[level].push_back(cand);
			//MaxFre[level].push (cand.name);
			if (max_level<level )
				max_level =level;
			//��������ж�cand�ĳ�ģʽ�Ƿ�ΪƵ��ģʽ
			bool result=mineFre(cand);
			//	�����ģʽ����Ƶ��ģʽ�����������ģʽ
			if (result==false)
			{
				MaxFre[level].push_back (cand.name);
				//MaxFre[level].pop ();
			}
		}
		//level++;
	}
	return flag;
}

void store_into_vec(seqdb sDB[K])
{
	int sid;
	for (sid = 0; sid < sequence_num; sid++)
	{
		percharsequence temp[M];
		string ss;
		percharsequence current_sequence;
		current_sequence.len = strlen(sDB[sid].S);
		len_seq.push_back(current_sequence.len);
		ss = sDB[sid].S;
		int i;
		for (i = 0; i < current_sequence.len; i++)
		{
			//if (ss[i]>='a'&&ss[i]<='z')
			//ss[i]-=32;
			for (int j = 0; j < sigmasize; j++)
			{
				if (ss[i] == sigma[j])
				{
					temp[j].store.push_back(i);
					break;
				}
			}
		}
		for (i = 0; i < sigmasize; i++)
		{
			temp[i].len = temp[i].store.size();
			SeqDB[i].push_back(temp[i]);
		}
		//prescan(sDB[parameter][sid].S,sigma,sigmasize,current_sequence.store );
		//SeqDB[][parameter].push_back (current_sequence);
	}
}

void min_sigma()
{
	 map <char, int > counter;
	 char mine;
	 for(int t = 0; t < sequence_num; t++)
	 {
		strcpy(S,sDB[t].S);
		for(int i=0;i<strlen(S);i++)
		{
			if ((S[i]>='a'&&S[i]<='z')||(S[i]>='A'&&S[i]<='Z'))
			{
				mine=S[i];
				counter[mine]++;
			}			
		}	 
	 }
	 sigmasize= 0;
	 for (map <char, int >::iterator the_iterator = counter.begin (); the_iterator!= counter.end (); the_iterator++)
	 {
		 sigma[sigmasize] = the_iterator->first;
		 sigmasize++;
		 /*if (the_iterator->second >= minsup)
		 {
			 sigma[sigmasize] = the_iterator->first;
			 sigmasize++;
		 } */
	}
}

void read_file()
{
	FILE *fp=NULL;
	//fstream file;
	string buff;
	char p[20];
	cout << "Input filename: " << endl; 
	//cin>>p;
	//file.open(p,ios::in);   //open sequence file

	//fp=fopen("credit.txt","r+");
	//fp=fopen("dataset/test4.txt","r+");
	//fp=fopen("dataset/dna6.txt","r+");
	fp=fopen("dataset/sdb2.txt","r+");
	int i = 0;
	while (fscanf(fp,"%s",sDB0[i].S )!= EOF)
	{
		//strcpy(sDB0[i].S, buff.c_str());
		i++;
	}
	fclose(fp);
	int filetype = 0;
	if (filetype == 1)
	{
		//read_file-labled
		for (int line = 0; line < i; line++) //separated in sDB1  sDB2
		{
			strcpy(sDB[sequence_num].S, sDB0[line].S + 1);
			sequence_num++;
		}
	}
	else
	{
		//read_file-non-labled
		for (int line = 0; line < i; line++) //separated in sDB1  sDB2
		{
			strcpy(sDB[sequence_num].S, sDB0[line].S);
			sequence_num++;
		}
	}
	cout << "sequence number: " << sequence_num << endl; //output the sequence number of sDB1
//	store_into_vec(sDB);
	//disp (SeqDB[0][0][0].store );
}
void main()
{
	freArr = new vector <sorted_incomplete_nettree>[M];
	MaxFre = new vector <string >[M];	 
	read_file();
	mingap=0;
	maxgap=10;
	min_sigma();
	store_into_vec(sDB);
	//cout<<"input the minsup:"<<endl;
	//cin>>minsup;
	minsup=1800;
	DWORD begintime=GetTickCount();
	dealingfirstlevel(freArr);
	for(int e = 0; e < freArr[0].size(); e++)    // each item
	{
		bool result=mineFre(freArr[0][e]);    // mining all frequent patterns
		if (result==false)
		{
			MaxFre[0].push_back (freArr[0][e].name );	
		}
	}
	//����i��Ƶ��ģʽ������liҲ��Ƶ��ģʽ���������i�����������ģʽ������Ҫ�Ժ�׺ģʽ���н�һ���ж�
	//ֻ���������ң���Ϊ����ltҲ��Ƶ��ģʽ���������������������������ʱt��δ��ΪƵ��ģʽ	�������Ҫ�����еĺ�׺ģʽ�������һ��

	for(int i = 1; i<=max_level; i++)
	{
		int size=MaxFre[i].size();
		string suffix;
		for(int j = 0; j<size;j++)
		{
			suffix=MaxFre[i][j].substr (1);
			for (vector <string >::iterator iter =MaxFre[i-1].begin ();iter!=MaxFre[i-1].end ();iter++)
			{
				string current =*iter;
				if (current==suffix)
				{
					MaxFre[i-1].erase (iter);
					break;
				}
			}
		}
		//cout<<endl;
	}

	DWORD endtime=GetTickCount();
	for( i = 0; i<=max_level; i++)
	{
		for(int j = 0; j<freArr[i].size();j++)
		{
			cout<<freArr[i][j].name<<"\t";
			frenum++;
		}
		cout<<endl;
	}
	cout<<"The number of frequent patterns:"<<frenum<<endl<<endl<<endl;

	int maxcount=0;
	for(i = 0; i<=max_level; i++)
	{
		int size=MaxFre[i].size();
		maxcount+=size;
		for(int j = 0; j<size;j++)
		{
			cout<<MaxFre[i][j]<<"\t";
			//MaxFre[i].pop ();
		//	maxcount++;
		}
		cout<<endl;
	}
	cout<<"The number of maximal patterns:"<<maxcount<<endl;


	cout <<"The time-consuming:"<<endtime-begintime<<"ms. \n";
	cout <<"The number of calculation:"<<compnum<<" \n";
}
